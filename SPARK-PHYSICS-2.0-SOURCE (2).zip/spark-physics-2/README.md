# SPARK PHYSICS 2.0 — Starter LMS

Versi pengembangan awal (MVP) dari SPARK PHYSICS lama. **Belum merupakan LMS produksi siap pakai.** Berisi fitur dasar dan kode sumber; perlu konfigurasi Supabase, pengujian, dan penguatan keamanan sebelum dipakai siswa sungguhan.

## Menjalankan di laptop
1. Install Node.js LTS (minimal versi 20.9) dan Visual Studio Code.
2. Buka folder ini di VS Code; buka Terminal.
3. Jalankan `npm install`.
4. Buat proyek baru di https://supabase.com dan buka SQL Editor. Jalankan seluruh `supabase/schema.sql`.
5. Salin `.env.example` menjadi `.env.local`; isi `NEXT_PUBLIC_SUPABASE_URL` dan `NEXT_PUBLIC_SUPABASE_ANON_KEY` dari Supabase Project Settings → API. **Jangan masukkan service_role key ke variabel NEXT_PUBLIC.**
6. Jalankan `npm run dev`, buka http://localhost:3000.
7. Daftar akun pertama melalui `/register`. Verifikasi email jika diwajibkan.
8. Untuk membuat admin pertama, jalankan perintah di SQL Editor Supabase (ganti email): `update public.profiles set role='admin' where id=(select id from auth.users where email='admin@contoh.com');`.
9. Login sebagai admin, buat kelas, lalu daftarkan siswa. Untuk membuat guru, ubah `role='teacher'` pada akun terverifikasi melalui SQL Editor (fitur manajemen role di dashboard belum tersedia).
10. Opsional AI: isi `OPENAI_API_KEY` di `.env.local`, restart server. Jangan publikasikan API key.

## Yang sudah diimplementasikan dalam kode
- Landing page light theme, login/registrasi via Supabase Auth, peran student/teacher/admin via database.
- Kelas, enrolment berdasarkan email, materi PDF/PPT di private storage dan tautan video.
- Pembuat asesmen pilihan ganda/esai, navigasi Back/Next/nomor soal, pengumpulan, koreksi pilihan ganda di server, esai disimpan.
- QR absensi yang berlaku 15 menit, token divalidasi server, rekap jumlah hadir.
- Grafik praktikum dari pasangan data x,y dan ekspor CSV (belum tersimpan di database).
- Refleksi, diskusi + balasan, chat grup dengan refresh manual, jadwal/link meeting.
- Umpan balik AI opsional untuk esai (bukan penilaian final), endpoint memerlukan sesi login.
- Salinan SPARK PHYSICS lama: `/legacy`.

## Keterbatasan yang penting
- Belum ada editor guru untuk nilai esai, rubrik lengkap, rekap nilai rinci, grafik monitoring, kalender terintegrasi, dashboard admin kelola peran, notifikasi realtime, atau audit log otomatis.
- Monitoring baru berupa fondasi log dan ringkasan pengumpulan; aktivitas belum otomatis tercatat. Tidak boleh mengklaim pelacakan aktivitas siswa penuh.
- Asesmen belum memiliki timer, bank soal, autosave server saat berpindah soal, pengacakan, atau aturan percobaan ulang. Jawaban sementara berada di memori browser; keluar halaman sebelum submit bisa menghilangkannya.
- API AI perlu rate limiting, moderasi dan kebijakan privasi sebelum digunakan skala sekolah. Jangan kirim data pribadi siswa ke AI tanpa persetujuan/kebijakan yang sesuai.
- Tidak ada Zoom yang di-host sendiri; guru memasukkan tautan meeting eksternal.
- QR dapat dibagikan antar siswa; token singkat + autentikasi mengurangi tetapi tidak menghilangkan titip absen.
- Keamanan dan SQL RLS perlu diuji menyeluruh sebelum produksi, termasuk storage, seluruh role, dan race condition.
- Tidak ada garansi gratis selamanya; kuota Supabase/Vercel dan API AI dapat berbiaya.

## Struktur
- `app/` Next.js pages, API AI, dan dashboard.
- `supabase/schema.sql` skema database dan Row Level Security.
- `public/legacy/` website lama, dipertahankan utuh.
- `legacy/SPARK-PHYSICS-1-main/` arsip kode asli.

## Rencana pengembangan selanjutnya
1. Autosave attempt dan assessment attempts dengan kebijakan penilaian esai.
2. Dashboard guru untuk penilaian esai, rubrik, dan laporan nilai/absensi.
3. Simpan grafik praktikum dan penilaian tugas; tambah statistik.
4. Chat real-time dan notifikasi.
5. Audit keamanan, pengujian lintas peran, aksesibilitas, dan uji beban.
