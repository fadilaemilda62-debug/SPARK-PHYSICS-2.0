import './globals.css';
export const metadata={title:'SPARK PHYSICS 2.0',description:'Learning Management System Fisika'};
export default function RootLayout({children}){return <html lang="id"><body>{children}</body></html>}
