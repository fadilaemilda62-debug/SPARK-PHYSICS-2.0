export default function Legacy(){return <main style={{height:'100vh'}}><iframe title="SPARK PHYSICS versi awal" src="/legacy/index.html" style={{width:'100%',height:'100%',border:0}}/></main>}
